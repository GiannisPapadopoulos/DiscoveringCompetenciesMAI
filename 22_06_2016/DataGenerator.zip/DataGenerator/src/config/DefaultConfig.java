package config;

import java.util.Properties;

public class DefaultConfig extends Properties{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5198124652350147660L;

	/**
	 * PARSED_CSV = ./input/Parsed.csv
	 * OUTPUT_PATH = ./output/Converted.csv
	 * DO_PARTICIPANT_FILTER = false
	 * DO_TIME_FILTER = false
	 * TIME_LIMIT = 01/01/2017
	 * PARTICIPANT_LIMIT = 0
	 */
	public DefaultConfig() {
		put(ConfigKeys.PARSED_CSV, "./input/Parsed.csv");
		put(ConfigKeys.OUTPUT_PATH,"./output/");
		put(ConfigKeys.DO_PARTICIPANT_FILTER, "false");
		put(ConfigKeys.DO_TIME_FILTER, "false");
		put(ConfigKeys.TIME_LIMIT, "01/01/2017");
		put(ConfigKeys.PARTICIPANT_LIMIT, "0");
	}
	
}
