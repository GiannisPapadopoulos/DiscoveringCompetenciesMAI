package config;

public enum ConfigKeys {

	/**
	 * Path of the Parsed.csv
	 */
	PARSED_CSV,
	/**
	 * Output folder path.
	 */
	OUTPUT_PATH,
	/**
	 * Time limit in format DAY/MONTH/YEAR
	 */
	TIME_LIMIT,
	/**
	 * Minimum of participants
	 */
	PARTICIPANT_LIMIT,
	/**
	 * Filter for time?
	 */
	DO_TIME_FILTER,
	/**
	 * Filter for participants?
	 */
	DO_PARTICIPANT_FILTER;
}
