package input;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import config.ConfigHandler;
import config.ConfigKeys;

public class ParticipantFilter {

	/**
	 * Filters all lines with courses that have too less participants.
	 * 
	 * The configuration entry of PARTICIPANT_LIMIT is used.
	 * 
	 * @param content The content of Parsed.csv.
	 * 
	 * @return A list with all courses with sufficient number of participants.
	 */
	public static List<String[]> filter(List<String[]>content){
		Map<String, Integer> map = countOccurrences(content);
		String partConf = ConfigHandler.getProperties(ConfigKeys.PARTICIPANT_LIMIT);
		int min = Integer.parseInt(partConf);
		
		List<String[]> anew = new ArrayList<String[]>();
		for (String[] line : content) {
			String key = line[1];
			
			if(map.get(key)>=min)
				anew.add(line);
		}
		return anew;
	}
	
	/**
	 * Counts the number of occurrences of courses.
	 * 
	 * @param content The content of Parsed.csv.
	 * 
	 * @return A map with key course-name and value occurrences.
	 */
	private static Map<String, Integer> countOccurrences(List<String[]>content){
		Map<String, Integer> map = new HashMap<String, Integer>();
		for (String[] line : content) {
			String key = line[1];
			if (map.containsKey(key))
				map.put(key, map.get(key) + 1);
			else
				map.put(key, 1);
		}
		return map;
	}
}
