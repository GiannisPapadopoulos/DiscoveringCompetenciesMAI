package run;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import config.ConfigHandler;
import config.ConfigKeys;
import convert.ConvertInput;
import convert.FullMatrix;
import input.ReadParsedCSV;
import output.DataWriter;

public class TestRun {

	public static void main(String[] args) {
		// First try to load the config
		ConfigHandler.loadConfig(new File("config.properties"));
		System.out.println("Config loaded.");

		try {
			List<String[]> content = ReadParsedCSV.readContent();
			
			//Or self-controlled
			//content = ConvertInput.applyFilters(content);
			//FullMatrix fullMatrix = ConvertInput.convertDataNoFilter(content);
			
			//// For more self-control
			////content = ConvertInput.applyFilters(content);
			////List<String> students = getValuesAt(content, 0);
			////List<String> courses = getValuesAt(content, 1);
			////double[][] values = getValueMatrix(content, students, courses);
			////FullMatrix fullMatrix = new FullMatrix(students,courses,values);
			
			FullMatrix fullMatrix = ConvertInput.convertData(content);
			
			String[][] out = DataWriter.combineCSV(fullMatrix.getStudentIDs(), fullMatrix.getCourseIDs(), fullMatrix.getSimpleMatrix().saved);
			
			System.out.println("Printing to "+ConfigHandler.getProperties(ConfigKeys.OUTPUT_PATH));
			DataWriter.printCSVData(out, ConfigHandler.getProperties(ConfigKeys.OUTPUT_PATH));
			
		} catch (FileNotFoundException e) {
			System.err.println(e.getMessage());
			System.exit(1);
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
		
	}
}
