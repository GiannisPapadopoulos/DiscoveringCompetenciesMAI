package test;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import convert.FullMatrix;
import convert.Matrix;
import input.ReadConvertedCSV;
import output.DataWriter;
import util.Wnnf;

public class WnnfTestWithData {

	public static void main(String[] args) throws IOException {
		
		FullMatrix fm = ReadConvertedCSV.readConvertedFile(new File("./output/cleaned.csv"));
		
	    double[][] matrix = fm.getSimpleMatrix().saved;

	    // String[][] out = DataWriter.combineCSV(studentIDs, courseIDs, outMatrix(matrix));
	    // DataWriter.printCSVData(out, "output/cleanded.csv");

	    // Transpose so that each stundent's grades are 1 column
	    Matrix A = new Matrix(matrix).transpose();

	    // System.out.println(W);

	    DataWriter.exportMatrixToCsv(A, "output/W.csv");
	    //for(int i = 1; i<20;i++){
	    // Should be set equal to the number of competences defined
	    int dimension = 4;

	    Matrix Winit = Matrix.random(A.length(), dimension);
	    Matrix Hinit = Matrix.random(dimension, A.width());

	    int numIterations = 1000;
	    Wnnf factorizer = new Wnnf(A, Winit, Hinit, numIterations);

	    Matrix result = factorizer.getReconctructedMatrix();

	    //DataWriter.exportMatrixToCsv(result, "output/Wnnf.csv");

	    System.out.println(factorizer.getW());
	    double [] sumOfRows = new double[factorizer.getW().saved.length];
	    double [][] normMatrix = new double[factorizer.getW().saved.length][factorizer.getW().saved[0].length];
	    
	    for(int i = 0;i<factorizer.getW().saved.length;i++){
	    	for(int j=0;j<factorizer.getW().saved[i].length;j++){
	    		sumOfRows[i]+=factorizer.getW().saved[i][j];
	    	}
	    }
	    for(int i = 0;i<factorizer.getW().saved.length;i++){
	    	for(int j=0;j<factorizer.getW().saved[i].length;j++){
	    		normMatrix[i][j]=factorizer.getW().saved[i][j]/sumOfRows[i];
	    	}
	    }
//	    System.out.println(Arrays.toString(sumOfRows));
	    for(double[] row:normMatrix)
	    	System.out.println(Arrays.toString(row));
	    
	    
//	    System.out.println(Arrays.deepToString(normMatrix));
	    //System.out.println(factorizer.getH());
	    }
	  //}

	}

