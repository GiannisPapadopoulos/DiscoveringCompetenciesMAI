package test;

import java.io.File;
import java.io.IOException;
import java.util.List;

import config.ConfigHandler;
import convert.ConvertInput;
import convert.FullMatrix;
import input.ReadParsedCSV;
import nmf.NMF;
import output.DataWriter;

public class Test {

	public static void main(String[] args) throws IOException {
		ConfigHandler.loadConfig(new File("config.properties"));
		List<String[]> content = ReadParsedCSV.readContent();

		FullMatrix fm = ConvertInput.convertData(content);

		double[][] matrix = fm.getSimpleMatrix().saved;
		String[][] out = DataWriter.combineCSV(fm.getStudentIDs(), fm.getCourseIDs(), fm.getSimpleMatrix().saved);
		DataWriter.printCSVData(out, "output/cleaned.csv");

		int dimension = 4;
		double[][] winit = NMF.random(matrix.length, dimension);
		double[][] hinit = NMF.random(dimension, matrix[0].length);

		int maxiter = 500;
		NMF.MultResult nmf = NMF.nmf(matrix, winit, hinit, 0.001, maxiter);
		double[][] result = nmf.matrix.mult(nmf.grad).saved;

		out = DataWriter.combineCSV(fm.getStudentIDs(), fm.getCourseIDs(), result);

		DataWriter.printCSVData(out, "output/nmfResult.csv");
	}

}
