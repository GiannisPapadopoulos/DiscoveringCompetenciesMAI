package preprocessing;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import config.Config;

public class DataReader {

	public static List<String[]> readContent() throws FileNotFoundException {
//		InputStream in = ClassLoader.getSystemResourceAsStream(Config
//				.getProperty("file"));
//		System.out.println(Config.getProperty("file"));
		Scanner scanner = new Scanner(new File("E:/workspace/Neuer Ordner/Parsed.csv"));

		List<String> content = new ArrayList<String>();
		while (scanner.hasNext()) {
			String line = scanner.nextLine();
			if (!content.contains(line))
				content.add(line);
		}
		scanner.close();
		return splitAll(content);
	}

	private static List<String[]> splitAll(List<String> content) {
		List<String[]> splits = new ArrayList<String[]>();
		for (String line : content)
			splits.add(line.split(","));
		return splits;
	}

}
