package config;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ConfigHandler {

	/**
	 * Holds the configurations
	 */
	private static Properties configuration = new Properties();

	/**
	 * A default configuration in case the normal one is invalid.
	 */
	private static final DefaultConfig defaultConf = new DefaultConfig();

	/**
	 * Tries to load the configuration from the given file. Uses default config
	 * otherwise.
	 * 
	 * @param config
	 *            The file of the config.
	 */
	public static void loadConfig(File config) {
		try {
			configuration.load(new FileInputStream(config));
		} catch (IOException e) {
			System.out.println("Config not accessible. Default is used for this run.");
			configuration = defaultConf;
		}
	}

	/**
	 * Gets the property for the given key. If not known, it uses the default
	 * config.
	 * 
	 * @param key
	 *            The key.
	 * @return The value.
	 */
	public static String getProperties(ConfigKeys key) {
		if (configuration.containsKey(key.name()) && !configuration.isEmpty()) {
			return configuration.getProperty(key.name());
		} else {
			return getDefaultProperty(key);
		}
	}

	public static String getDefaultProperty(ConfigKeys key) {
		System.out.println("Default value for key is used:" + key);
		return defaultConf.getProperty(key.name());
	}
}
