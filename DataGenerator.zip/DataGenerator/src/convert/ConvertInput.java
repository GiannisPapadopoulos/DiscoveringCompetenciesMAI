package convert;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import config.ConfigHandler;
import config.ConfigKeys;
import input.ParticipantFilter;
import input.TimeFilter;

public class ConvertInput {

	/**
	 * Converts a list of entries into a full matrix. Applies filters
	 * automatically.
	 * 
	 * @param content
	 *            The lists of entries.
	 * @return A FullMatrix with studentIDs,courseIDs and values-matrix.
	 */
	public static FullMatrix convertData(List<String[]> content) {
		content = applyFilters(content);

		return convertDataNoFilter(content);
	}

	/**
	 * Converts a list of entries into a full matrix. No filter is used.
	 * 
	 * @param content
	 *            The lists of entries.
	 * @return A FullMatrix with studentIDs,courseIDs and values-matrix.
	 */
	public static FullMatrix convertDataNoFilter(List<String[]> content) {
		List<String> students = getValuesAt(content, 0);
		List<String> courses = getValuesAt(content, 1);
		double[][] values = getValueMatrix(content, students, courses);

		FullMatrix fm = new FullMatrix(students, courses, values);
		return fm;
	}

	/**
	 * Reads the filter configurations and applies the filters if necessary.
	 * 
	 * @param content
	 *            The list of entries.
	 * @return The filtered list of entries.
	 */
	public static List<String[]> applyFilters(List<String[]> content) {
		String doTimeS = ConfigHandler.getProperties(ConfigKeys.DO_TIME_FILTER);
		boolean doTime = Boolean.parseBoolean(doTimeS);
		String doPartS = ConfigHandler.getProperties(ConfigKeys.DO_PARTICIPANT_FILTER);
		boolean doPart = Boolean.parseBoolean(doPartS);

		List<String[]> newContent = content;
		if (doTime) {
			System.out.println("Applying time filter...");
			newContent = TimeFilter.filter(content);
		}
		if (doPart) {
			System.out.println("Applying participant filter...");
			newContent = ParticipantFilter.filter(content);
		}
		return newContent;
	}

	/**
	 * Extracts the list of
	 * 	students for index = 0
	 *  courses for index = 1
	 *  
	 *  The list is sorted for good looking reasons :)
	 *  
	 * @param content The list of entries
	 * @param index Use as shown above.
	 * @return The requested list. No duplicates.
	 */
	public static List<String> getValuesAt(List<String[]> content, int index) {
		List<String> list = new ArrayList<String>();
		for (String[] line : content) {
			String id = line[index];
			if (!list.contains(id))
				list.add(id);
		}
		Collections.sort(list);
		return list;
	}

	/**
	 * Constructs the value matrix.
	 * 
	 * Row-index is the same index as the student-id in studentIDs.
	 * Col-index is the same index as the course-id in courseIDs.
	 * The last grade in time is used. To exclude times use the filters and insert the filtered content.
	 * 
	 * @param content Maybe filtered list of entries. Not necessary filtered.
	 * @param studentIDs The list of students
	 * @param courseIDs The list of courses
	 * @return The value matrix.
	 */
	public static double[][] getValueMatrix(List<String[]> content, List<String> studentIDs, List<String> courseIDs) {
		double[][] matrix = new double[studentIDs.size()][courseIDs.size()];
		// Fill with -1 to keep track of missing grades
		for (int i = 0; i < matrix.length; i++) {
			Arrays.fill(matrix[i], -1);
		}

		int[][] times = new int[studentIDs.size()][courseIDs.size()];
		for (String[] line : content) {
			int row = studentIDs.indexOf(line[0]);
			int col = courseIDs.indexOf(line[1]);
			double grade = Double.parseDouble(line[2]);
			int time = TimeFilter.parse(line[3]);

			if (times[row][col] < time) {
				times[row][col] = time;
				matrix[row][col] = grade;
			}
		}
		System.out.println("Constructed matrix:"+matrix.length+" x "+matrix[0].length);
		return matrix;
	}

}
