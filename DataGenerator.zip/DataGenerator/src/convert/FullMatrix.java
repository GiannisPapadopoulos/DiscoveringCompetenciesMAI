package convert;

import java.util.List;

public class FullMatrix {

	/**
	 * List of students (Index here = row index in sm)
	 */
	private List<String> studentIDs;
	
	/**
	 * List of courses (Index here = col index in sm)
	 */
	private List<String> courseIDs;
	
	/**
	 * The matrix as always.
	 */
	private Matrix sm;
	
	/**
	 * Complete matrix. With labels.
	 * @param students Initial students
	 * @param courses Initial courses
	 * @param values Initial values
	 */
	public FullMatrix(List<String> students, List<String> courses, double[][] values){
		setStudentIDs(students);
		setCourseIDs(courses);
		sm = new Matrix(values);
	}

	public List<String> getStudentIDs() {
		return studentIDs;
	}

	public void setStudentIDs(List<String> studentIDs) {
		this.studentIDs = studentIDs;
	}

	public List<String> getCourseIDs() {
		return courseIDs;
	}

	public void setCourseIDs(List<String> courseIDs) {
		this.courseIDs = courseIDs;
	}
	
	public Matrix getSimpleMatrix(){
		return sm;
	}
}
