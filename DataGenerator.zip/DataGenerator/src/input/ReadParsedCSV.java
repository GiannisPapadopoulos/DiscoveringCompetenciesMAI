package input;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import config.ConfigHandler;
import config.ConfigKeys;

public class ReadParsedCSV {

	/**
	 * Reads simply the lines of Parsed.csv without interpreting them.
	 * 
	 * The configuration entry of PARSED_CSV is used.
	 * 
	 * @return The list of splitted lines.
	 * @throws FileNotFoundException 
	 */
	public static List<String[]> readContent() throws FileNotFoundException {
		String input = ConfigHandler.getProperties(ConfigKeys.PARSED_CSV);
		System.out.println("Used input from " + input);

		// Reads all Parsed.csv
		FileInputStream in = new FileInputStream(new File(input));
		Scanner scanner = new Scanner(in);
		List<String> content = new ArrayList<String>();
		while (scanner.hasNext()) {
			String line = scanner.nextLine();
			if (!content.contains(line))
				content.add(line);
		}
		scanner.close();
		return splitAll(content);
	}

	/**
	 * Splits the lines of Parsed.csv
	 * 
	 * @param content
	 *            List of lines
	 * @return Splitted list of lines
	 */
	private static List<String[]> splitAll(List<String> content) {
		List<String[]> splits = new ArrayList<String[]>();
		for (String line : content)
			splits.add(line.split(","));
		return splits;
	}

}
