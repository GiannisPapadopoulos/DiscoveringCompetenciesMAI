package input;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import convert.FullMatrix;

public class ReadConvertedCSV {

	/**
	 * Read an already converted file.
	 * @param file
	 * @return
	 * @throws FileNotFoundException
	 */
	public static FullMatrix readConvertedFile(File file) throws FileNotFoundException{
		Scanner scanner = new Scanner(file);
		String[] coursesLine = scanner.nextLine().split(",");
		
		List<String> courses = new ArrayList<String>();
		//First field is empty
		for(int i=1;i<coursesLine.length;i++){
			courses.add(coursesLine[i]);
		}
		
		List<String> students = new ArrayList<String>();
		List<double[]> tmp = new ArrayList<double[]>();
		while(scanner.hasNext()){
			String[] line = scanner.nextLine().split(",");
			students.add(line[0]);
			double[] rest = new double[line.length-1];
			for(int i=1;i<line.length;i++){
				rest[i-1] = Double.parseDouble(line[i]);
			}
			tmp.add(rest);
		}
		scanner.close();
		
		double[][] values = new double[tmp.size()][tmp.get(0).length];
		for(int i=0;i<tmp.size();i++){
			values[i] = tmp.get(i);
		}
		
		FullMatrix fm = new FullMatrix(students, courses, values);
		return fm;
	}
	
}
