package input;

import java.util.ArrayList;
import java.util.List;

import config.ConfigHandler;
import config.ConfigKeys;

public class TimeFilter {

	/**
	 * Filters all lines which contain a time after the specified max.
	 * 
	 * The configuration entry of TIME_LIMIT is used.
	 * 
	 * @param content
	 *            The content of Parsed.csv.
	 * 
	 * @return A list with all entries before the specified time.
	 */
	public static List<String[]> filter(List<String[]> content) {
		String timeConf = ConfigHandler.getProperties(ConfigKeys.TIME_LIMIT);
		int max = parse(timeConf);

		List<String[]> anew = new ArrayList<String[]>();
		for (String[] line : content) {
			int time = parse(line[3]);
			if (time <= max)
				anew.add(line);
		}
		return anew;
	}

	/**
	 * Parses the String into a comparable time unit. 
	 * 
	 * The time has the format DAY/MONTH/YEAR.
	 * 
	 * 21/09/11 would result in 110921.
	 * 
	 * @param time The time in String format.
	 * @return The time unit with YEAR+MONTH+DAY.
	 */
	public static int parse(String time) {
		String[] split = time.split("/");
		return Integer.parseInt(split[2] + split[1] + split[0]);
	}
}
