package dataset;

import java.util.List;

import util.Times;

public class DataCleanser {

	public static double[][] getValueMatrix(List<String> studentIDs, List<String>courseIDs,List<String[]> content){
		return getValueMatrix(studentIDs, courseIDs, content,null);
	}
	
	
	public static double[][] getValueMatrix(List<String> studentIDs, List<String>courseIDs,List<String[]> content,String timeLimit){
		double[][] matrix = new double[studentIDs.size()][courseIDs.size()];
		int[][] times = new int[studentIDs.size()][courseIDs.size()];
		int limit = timeLimit == null ? -1 : Times.parse(timeLimit);
		for(String[]line:content){
			int row = studentIDs.indexOf(line[0]);
			int col = courseIDs.indexOf(line[1]);
			double grade = Double.parseDouble(line[2]);
			int time = Times.parse(line[3]);
			
			if(times[row][col]==0){
				times[row][col] = time;
				matrix[row][col] = grade;
				continue;
			}
			
			if(times[row][col]<time && (time==-1 || time<=limit)){
				times[row][col] = time;
				matrix[row][col] = grade;
			}
		}
		return matrix;
	}
	
	public static double[][] getValueMatrix2(List<String> studentIDs, List<String>courseIDs,List<String[]> content,String timeLimit){
		double[][] matrix = new double[studentIDs.size()][courseIDs.size()];
		int[][] times = new int[studentIDs.size()][courseIDs.size()];
		int limit = timeLimit == null ? -1 : Times.parse(timeLimit);
		for(String[]line:content){
			int row = studentIDs.indexOf(line[0]);
			int col = courseIDs.indexOf(line[1]);
			double grade = Double.parseDouble(line[2])+1;
			int time = Times.parse(line[3]);
			
			if(times[row][col]==0){
				times[row][col] = time;
				matrix[row][col] = grade;
				continue;
			}
			
			if(times[row][col]<time && (time==-1 || time<=limit)){
				times[row][col] = time;
				matrix[row][col] = grade;
			}
		}
		
		for(int i=0;i<matrix.length;i++)
			for(int j=0;j<matrix[i].length;j++)
				matrix[i][j]-=1;
		return matrix;
	}
	
	
}
